#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FZ TWEAKS v1.0 - Windows System Optimizer
Ein umfassendes PC-Tuning Tool mit über 100 Tweaks

GitHub: https://github.com/deinusername/FZ-Tweaks
License: MIT
"""

import os
import sys
import ctypes
import subprocess
import winreg
import json
import time
import shutil
import platform
from datetime import datetime
from pathlib import Path
from colorama import init, Fore, Back, Style

# Initialize colorama for colored terminal output
init(autoreset=True)

__version__ = "1.0.0"
__author__ = "Dein Name"
__license__ = "MIT"


class FZTweaks:
    """
    Hauptklasse für FZ Tweaks Windows Optimizer
    """
    
    def __init__(self):
        self.version = __version__
        self.backup_dir = Path.home() / "FZ_Tweaks_Backups"
        self.config_file = Path.home() / ".fz_tweaks_config.json"
        self.log_file = Path.home() / "FZ_Tweaks.log"
        self.tweaks_applied = []
        self.system_info = self._get_system_info()
        self.ensure_directories()
        
    def _get_system_info(self):
        """Sammelt Systeminformationen"""
        return {
            "os": platform.system(),
            "release": platform.release(),
            "version": platform.version(),
            "machine": platform.machine(),
            "processor": platform.processor(),
            "python_version": platform.python_version()
        }
    
    def ensure_directories(self):
        """Erstellt notwendige Verzeichnisse"""
        self.backup_dir.mkdir(exist_ok=True)
        
    def log(self, message, level="INFO"):
        """Schreibt in Log-Datei"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}] [{level}] {message}\n"
        with open(self.log_file, "a", encoding="utf-8") as f:
            f.write(log_entry)
        
    def is_admin(self):
        """Prüft ob das Programm mit Admin-Rechten läuft"""
        try:
            return ctypes.windll.shell32.IsUserAnAdmin()
        except Exception as e:
            self.log(f"Admin check failed: {e}", "ERROR")
            return False
        
    def run_as_admin(self):
        """Startet das Programm neu mit Admin-Rechten"""
        if not self.is_admin():
            print(Fore.YELLOW + "[!] Administrator-Rechte erforderlich!")
            print(Fore.YELLOW + "[*] Starte neu als Administrator...")
            try:
                ctypes.windll.shell32.ShellExecuteW(
                    None, "runas", sys.executable, " ".join(sys.argv), None, 1
                )
            except Exception as e:
                self.log(f"Failed to elevate: {e}", "ERROR")
                print(Fore.RED + f"[✗] Fehler beim Anfordern von Admin-Rechten: {e}")
            sys.exit()
    
    def clear_screen(self):
        """Löscht den Bildschirm"""
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def print_header(self):
        """Zeigt den Header an"""
        self.clear_screen()
        print(Fore.GREEN + r"""
    ███████╗███████╗    ████████╗██╗    ██╗███████╗ █████╗ ██╗  ██╗███████╗
    ██╔════╝╚══███╔╝    ╚══██╔══╝██║    ██║██╔════╝██╔══██╗██║ ██╔╝██╔════╝
    █████╗    ███╔╝        ██║   ██║ █╗ ██║█████╗  ███████║█████╔╝ ███████╗
    ██╔══╝   ███╔╝         ██║   ██║███╗██║██╔══╝  ██╔══██║██╔═██╗ ╚════██║
    ██║     ███████╗       ██║   ╚███╔███╔╝███████╗██║  ██║██║  ██╗███████║
    ╚═╝     ╚══════╝       ╚═╝    ╚══╝╚══╝ ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝
        """)
        print(Fore.CYAN + f"    Version {self.version} | Windows System Optimizer")
        print(Fore.YELLOW + "    " + "="*70)
        print(Fore.WHITE + f"    OS: Windows {self.system_info['release']} | "
              f"Python: {self.system_info['python_version']}")
        print(Fore.YELLOW + "    " + "="*70)
        print()
    
    def execute_command(self, command, description="", check=True):
        """
        Führt einen Systembefehl aus
        
        Args:
            command: Der auszuführende Befehl
            description: Beschreibung für die Ausgabe
            check: Ob auf Fehler geprüft werden soll
            
        Returns:
            bool: True bei Erfolg, False bei Fehler
        """
        try:
            if check:
                result = subprocess.run(
                    command, 
                    shell=True, 
                    capture_output=True, 
                    text=True,
                    encoding='utf-8',
                    errors='ignore'
                )
                success = result.returncode == 0
            else:
                # Fire and forget
                subprocess.Popen(command, shell=True)
                success = True
                
            if success:
                if description:
                    print(Fore.GREEN + f"[✓] {description}")
                    self.log(f"Success: {description}")
                return True
            else:
                error_msg = result.stderr if result.stderr else "Unbekannter Fehler"
                if description:
                    print(Fore.RED + f"[✗] {description} - Fehler: {error_msg}")
                    self.log(f"Error in {description}: {error_msg}", "ERROR")
                return False
                
        except Exception as e:
            if description:
                print(Fore.RED + f"[✗] {description} - Exception: {e}")
                self.log(f"Exception in {description}: {e}", "ERROR")
            return False
    
    def set_registry_value(self, path, name, value, value_type=winreg.REG_DWORD):
        """
        Setzt einen Registry-Wert
        
        Args:
            path: Registry-Pfad
            name: Wertname
            value: Wert
            value_type: Registry-Typ
            
        Returns:
            bool: True bei Erfolg
        """
        try:
            # Bestimme den Root-Key
            if path.startswith("HKEY_CURRENT_USER"):
                root = winreg.HKEY_CURRENT_USER
                sub_path = path.split("\\", 1)[1]
            elif path.startswith("HKEY_LOCAL_MACHINE"):
                root = winreg.HKEY_LOCAL_MACHINE
                sub_path = path.split("\\", 1)[1]
            elif path.startswith("HKEY_CLASSES_ROOT"):
                root = winreg.HKEY_CLASSES_ROOT
                sub_path = path.split("\\", 1)[1]
            else:
                root = winreg.HKEY_CURRENT_USER
                sub_path = path
            
            # Erstelle/Öffne Key
            key = winreg.CreateKey(root, sub_path)
            
            # Setze Wert
            if value_type == winreg.REG_SZ:
                winreg.SetValueEx(key, name, 0, value_type, str(value))
            else:
                winreg.SetValueEx(key, name, 0, value_type, int(value))
                
            winreg.CloseKey(key)
            return True
            
        except Exception as e:
            self.log(f"Registry error: {e}", "ERROR")
            return False
    
    def create_restore_point(self, description="FZ_Tweaks_Backup"):
        """Erstellt einen Systemwiederherstellungspunkt"""
        print(Fore.CYAN + f"\n[*] Erstelle Wiederherstellungspunkt...")
        try:
            subprocess.run([
                'powershell', '-Command',
                f'Checkpoint-Computer -Description "{description}" -RestorePointType MODIFY_SETTINGS'
            ], check=True)
            print(Fore.GREEN + "[✓] Wiederherstellungspunkt erstellt")
            return True
        except Exception as e:
            print(Fore.YELLOW + f"[!] Konnte Wiederherstellungspunkt nicht erstellen: {e}")
            return False
    
    # ==================== SYSTEM TWEAKS ====================
    
    def system_tweaks_menu(self):
        """System-Tweaks Menü"""
        while True:
            self.print_header()
            print(Fore.CYAN + "    [SYSTEM TWEAKS]")
            print(Fore.YELLOW + "    " + "-"*50)
            
            tweaks = [
                ("1", "Windows Update optimieren", self.tweak_windows_update),
                ("2", "Superfetch/PreFetch deaktivieren", self.tweak_superfetch),
                ("3", "Windows Search optimieren", self.tweak_windows_search),
                ("4", "SysMain deaktivieren", self.tweak_sysmain),
                ("5", "Hibernation deaktivieren", self.tweak_hibernation),
                ("6", "Fast Boot aktivieren", self.tweak_fastboot),
                ("7", "Boot-Timeout reduzieren", self.tweak_boot_timeout),
                ("8", "Automatische Wartung deaktivieren", self.tweak_maintenance),
                ("9", "Fehlerberichterstattung deaktivieren", self.tweak_error_reporting),
                ("10", "Windows Defender optimieren", self.tweak_defender),
                ("11", "Systemwiederherstellung konfigurieren", self.tweak_system_restore),
                ("12", "Pagefile optimieren", self.tweak_pagefile),
                ("13", "⚡ ALLE System-Tweaks anwenden", self.apply_all_system_tweaks),
            ]
            
            for num, name, _ in tweaks:
                print(Fore.WHITE + f"    [{num}] {name}")
            
            print(Fore.RED + "    [0] Zurück zum Hauptmenü")
            print()
            
            choice = input(Fore.GREEN + "    Auswahl: " + Fore.WHITE)
            
            if choice == '0':
                break
            elif choice in [t[0] for t in tweaks]:
                for num, _, func in tweaks:
                    if num == choice:
                        func()
                        break
                input(Fore.YELLOW + "\n    Drücke Enter zum Fortfahren...")
    
    def tweak_windows_update(self):
        """Optimiert Windows Update"""
        print(Fore.CYAN + "\n[*] Optimiere Windows Update...")
        commands = [
            ('reg add "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\WindowsUpdate\\AU" /v NoAutoRebootWithLoggedOnUsers /t REG_DWORD /d 1 /f', "Auto-Reboot deaktiviert"),
            ('reg add "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\WindowsUpdate\\AU" /v AUOptions /t REG_DWORD /d 2 /f', "Update auf Benachrichtigung"),
            ('reg add "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\WindowsUpdate\\AU" /v ScheduledInstallDay /t REG_DWORD /d 0 /f', "Geplante Installation deaktiviert"),
            ('reg add "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\DeliveryOptimization\\Config" /v DODownloadMode /t REG_DWORD /d 0 /f', "Delivery Optimization deaktiviert"),
        ]
        for cmd, desc in commands:
            self.execute_command(cmd, desc)
        self.tweaks_applied.append("Windows Update optimiert")
    
    def tweak_superfetch(self):
        """Deaktiviert Superfetch/SysMain"""
        print(Fore.CYAN + "\n[*] Deaktiviere Superfetch/PreFetch...")
        self.execute_command('sc stop "SysMain"', "SysMain gestoppt")
        self.execute_command('sc config "SysMain" start= disabled', "SysMain deaktiviert")
        self.execute_command('reg add "HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters" /v EnablePrefetcher /t REG_DWORD /d 0 /f', "Prefetch deaktiviert")
        self.execute_command('reg add "HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters" /v EnableSuperfetch /t REG_DWORD /d 0 /f', "Superfetch deaktiviert")
        self.tweaks_applied.append("Superfetch/PreFetch deaktiviert")
    
    def tweak_windows_search(self):
        """Optimiert Windows Search"""
        print(Fore.CYAN + "\n[*] Optimiere Windows Search...")
        self.execute_command('sc config "WSearch" start= disabled', "Windows Search deaktiviert")
        self.execute_command('sc stop "WSearch"', "Windows Search gestoppt")
        self.execute_command('reg add "HKLM\\SOFTWARE\\Microsoft\\Windows Search" /v SetupCompletedSuccessfully /t REG_DWORD /d 0 /f', "Search-Index zurückgesetzt")
        self.tweaks_applied.append("Windows Search optimiert")
    
    def tweak_sysmain(self):
        """Deaktiviert SysMain"""
        print(Fore.CYAN + "\n[*] Deaktiviere SysMain...")
        self.execute_command('sc stop "SysMain"', "SysMain gestoppt")
        self.execute_command('sc config "SysMain" start= disabled', "SysMain deaktiviert")
        self.tweaks_applied.append("SysMain deaktiviert")
    
    def tweak_hibernation(self):
        """Deaktiviert Hibernation"""
        print(Fore.CYAN + "\n[*] Deaktiviere Hibernation...")
        self.execute_command('powercfg /hibernate off', "Hibernation deaktiviert")
        self.execute_command('reg add "HKLM\\SYSTEM\\CurrentControlSet\\Control\\Power" /v HibernateEnabled /t REG_DWORD /d 0 /f', "Hibernate-Registry deaktiviert")
        self.tweaks_applied.append("Hibernation deaktiviert")
    
    def tweak_fastboot(self):
        """Aktiviert Fast Boot"""
        print(Fore.CYAN + "\n[*] Aktiviere Fast Boot...")
        self.execute_command('reg add "HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Power" /v HiberbootEnabled /t REG_DWORD /d 1 /f', "Fast Boot aktiviert")
        self.tweaks_applied.append("Fast Boot aktiviert")
    
    def tweak_boot_timeout(self):
        """Reduziert Boot-Timeout"""
        print(Fore.CYAN + "\n[*] Reduziere Boot-Timeout...")
        self.execute_command('bcdedit /timeout 3', "Boot-Timeout auf 3 Sekunden")
        self.tweaks_applied.append("Boot-Timeout reduziert")
    
    def tweak_maintenance(self):
        """Deaktiviert automatische Wartung"""
        print(Fore.CYAN + "\n[*] Deaktiviere Automatische Wartung...")
        self.execute_command('reg add "HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Schedule\\Maintenance" /v MaintenanceDisabled /t REG_DWORD /d 1 /f', "Automatische Wartung deaktiviert")
        self.tweaks_applied.append("Automatische Wartung deaktiviert")
    
    def tweak_error_reporting(self):
        """Deaktiviert Fehlerberichterstattung"""
        print(Fore.CYAN + "\n[*] Deaktiviere Fehlerberichterstattung...")
        self.execute_command('sc config "WerSvc" start= disabled', "Fehlerberichterstattung deaktiviert")
        self.execute_command('sc stop "WerSvc"', "Fehlerberichterstattung gestoppt")
        self.execute_command('reg add "HKLM\\SOFTWARE\\Microsoft\\Windows\\Windows Error Reporting" /v Disabled /t REG_DWORD /d 1 /f', "Wer-Registry deaktiviert")
        self.tweaks_applied.append("Fehlerberichterstattung deaktiviert")
    
    def tweak_defender(self):
        """Optimiert Windows Defender (nicht deaktivieren!)"""
        print(Fore.CYAN + "\n[*] Optimiere Windows Defender...")
        self.execute_command('reg add "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows Defender" /v DisableAntiSpyware /t REG_DWORD /d 0 /f', "Defender-Schutz aktiviert")
        self.execute_command('reg add "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows Defender\\Real-Time Protection" /v DisableIOAVProtection /t REG_DWORD /d 0 /f', "Echtzeitschutz aktiviert")
        self.tweaks_applied.append("Windows Defender optimiert")
    
    def tweak_system_restore(self):
        """Konfiguriert Systemwiederherstellung"""
        print(Fore.CYAN + "\n[*] Konfiguriere Systemwiederherstellung...")
        self.execute_command('vssadmin resize shadowstorage /for=C: /on=C: /maxsize=5GB', "Shadow-Storage auf 5GB")
        self.execute_command('reg add "HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\SystemRestore" /v DisableSR /t REG_DWORD /d 0 /f', "System Restore aktiviert")
        self.tweaks_applied.append("Systemwiederherstellung konfiguriert")
    
    def tweak_pagefile(self):
        """Optimiert Pagefile"""
        print(Fore.CYAN + "\n[*] Optimiere Pagefile...")
        self.execute_command('wmic computersystem where name="%computername%" set AutomaticManagedPagefile=False', "Automatische Verwaltung deaktiviert")
        self.execute_command('wmic pagefileset where name="C:\\\\pagefile.sys" set InitialSize=4096,MaximumSize=8192', "Pagefile auf 4-8GB")
        self.tweaks_applied.append("Pagefile optimiert")
    
    def apply_all_system_tweaks(self):
        """Wendet alle System-Tweaks an"""
        print(Fore.YELLOW + "\n[!] Wende alle System-Tweaks an...")
        self.tweak_windows_update()
        self.tweak_superfetch()
        self.tweak_windows_search()
        self.tweak_sysmain()
        self.tweak_hibernation()
        self.tweak_fastboot()
        self.tweak_boot_timeout()
        self.tweak_maintenance()
        self.tweak_error_reporting()
        self.tweak_defender()
        self.tweak_system_restore()
        self.tweak_pagefile()
        print(Fore.GREEN + "\n[✓] Alle System-Tweaks angewendet!")
    
    # ==================== GAMING TWEAKS ====================
    
    def gaming_tweaks_menu(self):
        """Gaming-Tweaks Menü"""
        while True:
            self.print_header()
            print(Fore.CYAN + "    [GAMING TWEAKS]")
            print(Fore.YELLOW + "    " + "-"*50)
            
            tweaks = [
                ("1", "Game Mode aktivieren", self.tweak_game_mode),
                ("2", "Xbox Game Bar deaktivieren", self.tweak_xbox_gamebar),
                ("3", "Vollbild-Optimierungen deaktivieren", self.tweak_fullscreen_optimizations),
                ("4", "HAGS aktivieren", self.tweak_hags),
                ("5", "Nagle-Algorithmus deaktivieren", self.tweak_nagle),
                ("6", "Multimedia-Priorität optimieren", self.tweak_multimedia_priority),
                ("7", "Visuelle Effekte reduzieren", self.tweak_visual_effects),
                ("8", "Prozessor-Scheduling optimieren", self.tweak_processor_scheduling),
                ("9", "Gaming-Dienste optimieren", self.tweak_gaming_services),
                ("10", "GPU-Timeout erhöhen", self.tweak_gpu_timeout),
                ("11", "⚡ ALLE Gaming-Tweaks anwenden", self.apply_all_gaming_tweaks),
            ]
            
            for num, name, _ in tweaks:
                print(Fore.WHITE + f"    [{num}] {name}")
            
            print(Fore.RED + "    [0] Zurück zum Hauptmenü")
            print()
            
            choice = input(Fore.GREEN + "    Auswahl: " + Fore.WHITE)
            
            if choice == '0':
                break
            elif choice in [t[0] for t in tweaks]:
                for num, _, func in tweaks:
                    if num == choice:
                        func()
                        break
                input(Fore.YELLOW + "\n    Drücke Enter zum Fortfahren...")
    
    def tweak_game_mode(self):
        """Aktiviert Game Mode"""
        print(Fore.CYAN + "\n[*] Aktiviere Game Mode...")
        self.execute_command('reg add "HKCU\\Software\\Microsoft\\GameBar" /v AllowAutoGameMode /t REG_DWORD /d 1 /f', "Game Mode aktiviert")
        self.execute_command('reg add "HKCU\\Software\\Microsoft\\GameBar" /v AutoGameModeEnabled /t REG_DWORD /d 1 /f', "Auto-Game-Mode aktiviert")
        self.tweaks_applied.append("Game Mode aktiviert")
    
    def tweak_xbox_gamebar(self):
        """Deaktiviert Xbox Game Bar"""
        print(Fore.CYAN + "\n[*] Deaktiviere Xbox Game Bar...")
        self.execute_command('reg add "HKCU\\Software\\Microsoft\\GameBar" /v ShowStartupPanel /t REG_DWORD /d 0 /f', "Game Bar Startup deaktiviert")
        self.execute_command('reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\GameDVR" /v AppCaptureEnabled /t REG_DWORD /d 0 /f', "Game DVR deaktiviert")
        self.execute_command('sc config "XblAuthManager" start= disabled', "Xbox Auth Manager deaktiviert")
        self.execute_command('sc config "XblGameSave" start= disabled', "Xbox Game Save deaktiviert")
        self.tweaks_applied.append("Xbox Game Bar deaktiviert")
    
    def tweak_fullscreen_optimizations(self):
        """Deaktiviert Vollbild-Optimierungen"""
        print(Fore.CYAN + "\n[*] Deaktiviere Vollbild-Optimierungen...")
        self.execute_command('reg add "HKCU\\System\\GameConfigStore" /v GameDVR_FSEBehaviorMode /t REG_DWORD /d 2 /f', "FSE-Behavior aktiviert")
        self.execute_command('reg add "HKCU\\System\\GameConfigStore" /v GameDVR_HonorUserFSEBehaviorMode /t REG_DWORD /d 1 /f', "FSE erzwungen")
        self.tweaks_applied.append("Vollbild-Optimierungen deaktiviert")
    
    def tweak_hags(self):
        """Aktiviert Hardware-Accelerated GPU Scheduling"""
        print(Fore.CYAN + "\n[*] Aktiviere HAGS...")
        self.execute_command('reg add "HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers" /v HwSchMode /t REG_DWORD /d 2 /f', "HAGS aktiviert")
        self.tweaks_applied.append("HAGS aktiviert")
    
    def tweak_nagle(self):
        """Deaktiviert Nagle-Algorithmus"""
        print(Fore.CYAN + "\n[*] Deaktiviere Nagle-Algorithmus...")
        self.execute_command('reg add "HKLM\\SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters\\Interfaces" /v TcpAckFrequency /t REG_DWORD /d 1 /f', "TCP Ack Frequency optimiert")
        self.execute_command('reg add "HKLM\\SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters\\Interfaces" /v TCPNoDelay /t REG_DWORD /d 1 /f', "TCP No Delay aktiviert")
        self.tweaks_applied.append("Nagle-Algorithmus deaktiviert")
    
    def tweak_multimedia_priority(self):
        """Optimiert Multimedia-Systempriorität"""
        print(Fore.CYAN + "\n[*] Optimiere Multimedia-Priorität...")
        self.execute_command('reg add "HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile" /v SystemResponsiveness /t REG_DWORD /d 0 /f', "System-Responsiveness auf 0")
        self.execute_command('reg add "HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games" /v "GPU Priority" /t REG_DWORD /d 8 /f', "GPU-Priorität für Games auf 8")
        self.execute_command('reg add "HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games" /v "Priority" /t REG_DWORD /d 6 /f', "Priorität für Games auf 6")
        self.tweaks_applied.append("Multimedia-Priorität optimiert")
    
    def tweak_visual_effects(self):
        """Reduziert visuelle Effekte"""
        print(Fore.CYAN + "\n[*] Reduziere visuelle Effekte...")
        self.execute_command('reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\VisualEffects" /v VisualFXSetting /t REG_DWORD /d 2 /f', "Visuelle Effekte auf 'Beste Leistung'")
        self.tweaks_applied.append("Visuelle Effekte reduziert")
    
    def tweak_processor_scheduling(self):
        """Optimiert Prozessor-Scheduling"""
        print(Fore.CYAN + "\n[*] Optimiere Prozessor-Scheduling...")
        self.execute_command('reg add "HKLM\\SYSTEM\\CurrentControlSet\\Control\\PriorityControl" /v Win32PrioritySeparation /t REG_DWORD /d 38 /f', "Win32 Priority Separation optimiert")
        self.tweaks_applied.append("Prozessor-Scheduling optimiert")
    
    def tweak_gaming_services(self):
        """Deaktiviert unnötige Gaming-Dienste"""
        print(Fore.CYAN + "\n[*] Deaktiviere Gaming-Dienste...")
        services = ["DiagTrack", "dmwappushservice", "MapsBroker", "WMPNetworkSvc", "WSearch"]
        for service in services:
            self.execute_command(f'sc config "{service}" start= disabled', f"{service} deaktiviert")
            self.execute_command(f'sc stop "{service}"', f"{service} gestoppt")
        self.tweaks_applied.append("Gaming-Dienste optimiert")
    
    def tweak_gpu_timeout(self):
        """Erhöht GPU-Timeout"""
        print(Fore.CYAN + "\n[*] Erhöhe GPU-Timeout...")
        self.execute_command('reg add "HKLM\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers" /v TdrDelay /t REG_DWORD /d 10 /f', "TDR-Delay erhöht")
        self.tweaks_applied.append("GPU-Timeout erhöht")
    
    def apply_all_gaming_tweaks(self):
        """Wendet alle Gaming-Tweaks an"""
        print(Fore.YELLOW + "\n[!] Wende alle Gaming-Tweaks an...")
        self.tweak_game_mode()
        self.tweak_xbox_gamebar()
        self.tweak_fullscreen_optimizations()
        self.tweak_hags()
        self.tweak_nagle()
        self.tweak_multimedia_priority()
        self.tweak_visual_effects()
        self.tweak_processor_scheduling()
        self.tweak_gaming_services()
        self.tweak_gpu_timeout()
        print(Fore.GREEN + "\n[✓] Alle Gaming-Tweaks angewendet!")
    
    # ==================== PRIVACY TWEAKS ====================
    
    def privacy_tweaks_menu(self):
        """Privacy-Tweaks Menü"""
        while True:
            self.print_header()
            print(Fore.CYAN + "    [PRIVACY TWEAKS]")
            print(Fore.YELLOW + "    " + "-"*50)
            
            tweaks = [
                ("1", "Telemetrie deaktivieren", self.tweak_telemetry),
                ("2", "Diagnose-Daten minimieren", self.tweak_diagnostic_data),
                ("3", "Werbe-ID deaktivieren", self.tweak_advertising_id),
                ("4", "Cortana deaktivieren", self.tweak_cortana),
                ("5", "Standort-Dienste deaktivieren", self.tweak_location),
                ("6", "Spracherkennung deaktivieren", self.tweak_speech),
                ("7", "Inkognito-Suche deaktivieren", self.tweak_ink_search),
                ("8", "Aktivitätsverlauf deaktivieren", self.tweak_activity_history),
                ("9", "Feedback-Dienste deaktivieren", self.tweak_feedback),
                ("10", "App-Permissions deaktivieren", self.tweak_app_permissions),
                ("11", "⚡ ALLE Privacy-Tweaks anwenden", self.apply_all_privacy_tweaks),
            ]
            
            for num, name, _ in tweaks:
                print(Fore.WHITE + f"    [{num}] {name}")
            
            print(Fore.RED + "    [0] Zurück zum Hauptmenü")
            print()
            
            choice = input(Fore.GREEN + "    Auswahl: " + Fore.WHITE)
            
            if choice == '0':
                break
            elif choice in [t[0] for t in tweaks]:
                for num, _, func in tweaks:
                    if num == choice:
                        func()
                        break
                input(Fore.YELLOW + "\n    Drücke Enter zum Fortfahren...")
    
    def tweak_telemetry(self):
        """Deaktiviert Telemetrie"""
        print(Fore.CYAN + "\n[*] Deaktiviere Telemetrie...")
        self.execute_command('sc config "DiagTrack" start= disabled', "DiagTrack deaktiviert")
        self.execute_command('sc stop "DiagTrack"', "DiagTrack gestoppt")
        self.execute_command('sc config "dmwappushservice" start= disabled', "dmwappushservice deaktiviert")
        self.execute_command('reg add "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection" /v AllowTelemetry /t REG_DWORD /d 0 /f', "Telemetrie deaktiviert")
        self.tweaks_applied.append("Telemetrie deaktiviert")
    
    def tweak_diagnostic_data(self):
        """Minimiert Diagnose-Daten"""
        print(Fore.CYAN + "\n[*] Minimiere Diagnose-Daten...")
        self.execute_command('reg add "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\DataCollection" /v MaxTelemetryAllowed /t REG_DWORD /d 0 /f', "Max-Telemetry auf 0")
        self.tweaks_applied.append("Diagnose-Daten minimiert")
    
    def tweak_advertising_id(self):
        """Deaktiviert Werbe-ID"""
        print(Fore.CYAN + "\n[*] Deaktiviere Werbe-ID...")
        self.execute_command('reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\AdvertisingInfo" /v Enabled /t REG_DWORD /d 0 /f', "Werbe-ID deaktiviert")
        self.execute_command('reg add "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\AdvertisingInfo" /v DisabledByGroupPolicy /t REG_DWORD /d 1 /f', "Werbe-ID per Policy deaktiviert")
        self.tweaks_applied.append("Werbe-ID deaktiviert")
    
    def tweak_cortana(self):
        """Deaktiviert Cortana"""
        print(Fore.CYAN + "\n[*] Deaktiviere Cortana...")
        self.execute_command('reg add "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search" /v AllowCortana /t REG_DWORD /d 0 /f', "Cortana deaktiviert")
        self.execute_command('reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Search" /v CortanaEnabled /t REG_DWORD /d 0 /f', "Cortana-User deaktiviert")
        self.tweaks_applied.append("Cortana deaktiviert")
    
    def tweak_location(self):
        """Deaktiviert Standort-Dienste"""
        print(Fore.CYAN + "\n[*] Deaktiviere Standort-Dienste...")
        self.execute_command('reg add "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\CapabilityAccessManager\\ConsentStore\\location" /v Value /t REG_SZ /d Deny /f', "Standortzugriff verweigert")
        self.execute_command('sc config "lfsvc" start= disabled', "Location-Service deaktiviert")
        self.tweaks_applied.append("Standort-Dienste deaktiviert")
    
    def tweak_speech(self):
        """Deaktiviert Spracherkennung"""
        print(Fore.CYAN + "\n[*] Deaktiviere Spracherkennung...")
        self.execute_command('reg add "HKCU\\Software\\Microsoft\\Speech_OneCore\\Settings\\OnlineSpeechPrivacy" /v HasAcceptedOnlineSpeechPrivacy /t REG_DWORD /d 0 /f', "Online-Spracherkennung deaktiviert")
        self.tweaks_applied.append("Spracherkennung deaktiviert")
    
    def tweak_ink_search(self):
        """Deaktiviert Inkognito-Suche"""
        print(Fore.CYAN + "\n[*] Deaktiviere Inkognito-Suche...")
        self.execute_command('reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Search" /v BingSearchEnabled /t REG_DWORD /d 0 /f', "Bing-Suche deaktiviert")
        self.tweaks_applied.append("Inkognito-Suche deaktiviert")
    
    def tweak_activity_history(self):
        """Deaktiviert Aktivitätsverlauf"""
        print(Fore.CYAN + "\n[*] Deaktiviere Aktivitätsverlauf...")
        self.execute_command('reg add "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\System" /v PublishUserActivities /t REG_DWORD /d 0 /f', "User-Activities deaktiviert")
        self.execute_command('reg add "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\System" /v UploadUserActivities /t REG_DWORD /d 0 /f', "Upload-Activities deaktiviert")
        self.tweaks_applied.append("Aktivitätsverlauf deaktiviert")
    
    def tweak_feedback(self):
        """Deaktiviert Feedback-Dienste"""
        print(Fore.CYAN + "\n[*] Deaktiviere Feedback-Dienste...")
        self.execute_command('reg add "HKCU\\Software\\Microsoft\\Siuf\\Rules" /v NumberOfSIUFInPeriod /t REG_DWORD /d 0 /f', "SIUF deaktiviert")
        self.tweaks_applied.append("Feedback-Dienste deaktiviert")
    
    def tweak_app_permissions(self):
        """Deaktiviert App-Permissions"""
        print(Fore.CYAN + "\n[*] Deaktiviere App-Permissions...")
        permissions = ["contacts", "calendar", "callhistory", "email", "chat"]
        for perm in permissions:
            self.execute_command(f'reg add "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\CapabilityAccessManager\\ConsentStore\\{perm}" /v Value /t REG_SZ /d Deny /f', f"{perm}-Zugriff verweigert")
        self.tweaks_applied.append("App-Permissions deaktiviert")
    
    def apply_all_privacy_tweaks(self):
        """Wendet alle Privacy-Tweaks an"""
        print(Fore.YELLOW + "\n[!] Wende alle Privacy-Tweaks an...")
        self.tweak_telemetry()
        self.tweak_diagnostic_data()
        self.tweak_advertising_id()
        self.tweak_cortana()
        self.tweak_location()
        self.tweak_speech()
        self.tweak_ink_search()
        self.tweak_activity_history()
        self.tweak_feedback()
        self.tweak_app_permissions()
        print(Fore.GREEN + "\n[✓] Alle Privacy-Tweaks angewendet!")
    
    # ==================== NETWORK TWEAKS ====================
    
    def network_tweaks_menu(self):
        """Network-Tweaks Menü"""
        while True:
            self.print_header()
            print(Fore.CYAN + "    [NETWORK TWEAKS]")
            print(Fore.YELLOW + "    " + "-"*50)
            
            tweaks = [
                ("1", "TCP-Optimierung", self.tweak_tcp),
                ("2", "QoS-Paketplaner deaktivieren", self.tweak_qos),
                ("3", "Netzwerk-Durchsatz optimieren", self.tweak_throughput),
                ("4", "DNS-Cache optimieren", self.tweak_dns_cache),
                ("5", "NetBIOS deaktivieren", self.tweak_netbios),
                ("6", "LMHOSTS deaktivieren", self.tweak_lmhosts),
                ("7", "IPv6 deaktivieren", self.tweak_ipv6),
                ("8", "⚡ ALLE Network-Tweaks anwenden", self.apply_all_network_tweaks),
            ]
            
            for num, name, _ in tweaks:
                print(Fore.WHITE + f"    [{num}] {name}")
            
            print(Fore.RED + "    [0] Zurück zum Hauptmenü")
            print()
            
            choice = input(Fore.GREEN + "    Auswahl: " + Fore.WHITE)
            
            if choice == '0':
                break
            elif choice in [t[0] for t in tweaks]:
                for num, _, func in tweaks:
                    if num == choice:
                        func()
                        break
                input(Fore.YELLOW + "\n    Drücke Enter zum Fortfahren...")
    
    def tweak_tcp(self):
        """Optimiert TCP-Einstellungen"""
        print(Fore.CYAN + "\n[*] Optimiere TCP...")
        self.execute_command('netsh int tcp set global autotuninglevel=normal', "TCP-Autotuning")
        self.execute_command('netsh int tcp set global rss=enabled', "TCP-RSS aktiviert")
        self.execute_command('netsh int tcp set global timestamps=disabled', "TCP-Timestamps deaktiviert")
        self.execute_command('reg add "HKLM\\SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters" /v TcpTimedWaitDelay /t REG_DWORD /d 30 /f', "TCP-Timed-Wait auf 30")
        self.tweaks_applied.append("TCP optimiert")
    
    def tweak_qos(self):
        """Optimiert QoS"""
        print(Fore.CYAN + "\n[*] Optimiere QoS...")
        self.execute_command('reg add "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Psched" /v NonBestEffortLimit /t REG_DWORD /d 0 /f', "QoS-Limit auf 0")
        self.tweaks_applied.append("QoS optimiert")
    
    def tweak_throughput(self):
        """Optimiert Netzwerk-Durchsatz"""
        print(Fore.CYAN + "\n[*] Optimiere Netzwerk-Durchsatz...")
        self.execute_command('reg add "HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile" /v NetworkThrottlingIndex /t REG_DWORD /d 4294967295 /f', "Network-Throttling deaktiviert")
        self.tweaks_applied.append("Netzwerk-Durchsatz optimiert")
    
    def tweak_dns_cache(self):
        """Optimiert DNS-Cache"""
        print(Fore.CYAN + "\n[*] Optimiere DNS-Cache...")
        self.execute_command('reg add "HKLM\\SYSTEM\\CurrentControlSet\\Services\\Dnscache\\Parameters" /v MaxCacheEntryTtlLimit /t REG_DWORD /d 64000 /f', "DNS-Cache-TTL optimiert")
        self.tweaks_applied.append("DNS-Cache optimiert")
    
    def tweak_netbios(self):
        """Deaktiviert NetBIOS"""
        print(Fore.CYAN + "\n[*] Deaktiviere NetBIOS...")
        self.execute_command('reg add "HKLM\\SYSTEM\\CurrentControlSet\\Services\\NetBT\\Parameters\\Interfaces\\Tcpip*" /v NetbiosOptions /t REG_DWORD /d 2 /f', "NetBIOS deaktiviert")
        self.tweaks_applied.append("NetBIOS deaktiviert")
    
    def tweak_lmhosts(self):
        """Deaktiviert LMHOSTS"""
        print(Fore.CYAN + "\n[*] Deaktiviere LMHOSTS...")
        self.execute_command('reg add "HKLM\\SYSTEM\\CurrentControlSet\\Services\\NetBT\\Parameters" /v EnableLMHosts /t REG_DWORD /d 0 /f', "LMHOSTS deaktiviert")
        self.tweaks_applied.append("LMHOSTS deaktiviert")
    
    def tweak_ipv6(self):
        """Deaktiviert IPv6"""
        print(Fore.CYAN + "\n[*] Deaktiviere IPv6...")
        self.execute_command('reg add "HKLM\\SYSTEM\\CurrentControlSet\\Services\\Tcpip6\\Parameters" /v DisabledComponents /t REG_DWORD /d 255 /f', "IPv6 deaktiviert")
        self.tweaks_applied.append("IPv6 deaktiviert")
    
    def apply_all_network_tweaks(self):
        """Wendet alle Network-Tweaks an"""
        print(Fore.YELLOW + "\n[!] Wende alle Network-Tweaks an...")
        self.tweak_tcp()
        self.tweak_qos()
        self.tweak_throughput()
        self.tweak_dns_cache()
        self.tweak_netbios()
        self.tweak_lmhosts()
        self.tweak_ipv6()
        print(Fore.GREEN + "\n[✓] Alle Network-Tweaks angewendet!")
    
    # ==================== DEBLOAT ====================
    
    def debloat_menu(self):
        """Debloat Menü"""
        while True:
            self.print_header()
            print(Fore.RED + "    [DEBLOAT - BLOATWARE ENTFERNEN]")
            print(Fore.YELLOW + "    " + "-"*50)
            
            options = [
                ("1", "Xbox Apps entfernen"),
                ("2", "OneDrive deinstallieren"),
                ("3", "Skype entfernen"),
                ("4", "Cortana App entfernen"),
                ("5", "Mail & Kalender entfernen"),
                ("6", "Fotos-App entfernen"),
                ("7", "Medien-Apps entfernen"),
                ("8", "News & Wetter entfernen"),
                ("9", "Spiele entfernen"),
                ("10", "Office-Hub entfernen"),
                ("11", "🔥 ALLE Bloatware entfernen"),
                ("12", "Windows-Features verwalten"),
            ]
            
            for num, name in options:
                print(Fore.WHITE + f"    [{num}] {name}")
            
            print(Fore.RED + "    [0] Zurück zum Hauptmenü")
            print()
            
            choice = input(Fore.GREEN + "    Auswahl: " + Fore.WHITE)
            
            if choice == '0':
                break
            elif choice == '1':
                self.remove_app("Xbox", "Xbox Apps")
            elif choice == '2':
                self.debloat_onedrive()
            elif choice == '3':
                self.remove_app("Skype", "Skype")
            elif choice == '4':
                self.remove_app("Microsoft.549981C3F5F10", "Cortana")
            elif choice == '5':
                self.remove_app("windowscommunicationsapps", "Mail & Kalender")
            elif choice == '6':
                self.remove_app("Windows.Photos", "Fotos-App")
            elif choice == '7':
                self.remove_app("ZuneMusic", "Groove Musik")
                self.remove_app("ZuneVideo", "Filme & TV")
            elif choice == '8':
                self.remove_app("BingNews", "News")
                self.remove_app("BingWeather", "Wetter")
            elif choice == '9':
                self.remove_app("Solitaire", "Microsoft Solitaire")
                self.remove_app("CandyCrush", "Candy Crush")
            elif choice == '10':
                self.remove_app("MicrosoftOfficeHub", "Office-Hub")
            elif choice == '11':
                self.debloat_all()
            elif choice == '12':
                self.windows_features_menu()
            
            if choice != '0':
                input(Fore.YELLOW + "\n    Drücke Enter zum Fortfahren...")
    
    def remove_app(self, app_name, display_name):
        """Entfernt eine Windows-App"""
        print(Fore.CYAN + f"\n[*] Entferne {display_name}...")
        self.execute_command(f'powershell -Command "Get-AppxPackage *{app_name}* | Remove-AppxPackage"', f"{display_name} entfernt")
        self.tweaks_applied.append(f"{display_name} entfernt")
    
    def debloat_onedrive(self):
        """Deinstalliert OneDrive"""
        print(Fore.CYAN + "\n[*] Deinstalliere OneDrive...")
        self.execute_command('taskkill /f /im OneDrive.exe', "OneDrive beendet")
        self.execute_command(r'C:\Windows\System32\OneDriveSetup.exe /uninstall', "OneDrive deinstalliert")
        self.execute_command('reg add "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\OneDrive" /v DisableFileSyncNGSC /t REG_DWORD /d 1 /f', "OneDrive-Sync deaktiviert")
        self.tweaks_applied.append("OneDrive deinstalliert")
    
    def debloat_all(self):
        """Entfernt alle Bloatware"""
        print(Fore.YELLOW + "\n[!] Entferne ALLE Bloatware-Apps...")
        apps = [
            ("Xbox", "Xbox"),
            ("Skype", "Skype"),
            ("Microsoft.549981C3F5F10", "Cortana"),
            ("windowscommunicationsapps", "Mail & Kalender"),
            ("Windows.Photos", "Fotos"),
            ("ZuneMusic", "Musik"),
            ("ZuneVideo", "Video"),
            ("BingNews", "News"),
            ("BingWeather", "Wetter"),
            ("Solitaire", "Solitaire"),
            ("CandyCrush", "Candy Crush"),
            ("MicrosoftOfficeHub", "Office-Hub"),
            ("YourPhone", "Ihr Smartphone"),
            ("Getstarted", "Erste Schritte"),
        ]
        for app_id, name in apps:
            self.remove_app(app_id, name)
        self.debloat_onedrive()
        print(Fore.GREEN + "\n[✓] Alle Bloatware-Apps entfernt!")
    
    def windows_features_menu(self):
        """Windows Features Menü"""
        print(Fore.CYAN + "\n[*] Windows-Features...")
        self.execute_command('optionalfeatures', "Windows-Features geöffnet")
    
    # ==================== MAINTENANCE ====================
    
    def maintenance_menu(self):
        """Wartungs-Menü"""
        while True:
            self.print_header()
            print(Fore.CYAN + "    [WARTUNG & REINIGUNG]")
            print(Fore.YELLOW + "    " + "-"*50)
            
            options = [
                ("1", "Temp-Dateien bereinigen"),
                ("2", "DNS-Cache leeren"),
                ("3", "Prefetch leeren"),
                ("4", "Recycle Bin leeren"),
                ("5", "SFC-Scan durchführen"),
                ("6", "DISM-Scan durchführen"),
                ("7", "Defragmentierung"),
                ("8", "Alles bereinigen"),
            ]
            
            for num, name in options:
                print(Fore.WHITE + f"    [{num}] {name}")
            
            print(Fore.RED + "    [0] Zurück zum Hauptmenü")
            print()
            
            choice = input(Fore.GREEN + "    Auswahl: " + Fore.WHITE)
            
            if choice == '0':
                break
            elif choice == '1':
                self.clean_temp()
            elif choice == '2':
                self.flush_dns()
            elif choice == '3':
                self.clean_prefetch()
            elif choice == '4':
                self.empty_recycle_bin()
            elif choice == '5':
                self.run_sfc()
            elif choice == '6':
                self.run_dism()
            elif choice == '7':
                self.defrag()
            elif choice == '8':
                self.clean_all()
            
            if choice != '0':
                input(Fore.YELLOW + "\n    Drücke Enter zum Fortfahren...")
    
    def clean_temp(self):
        """Bereinigt Temp-Dateien"""
        print(Fore.CYAN + "\n[*] Bereinige Temp-Dateien...")
        temp_paths = [os.environ.get('TEMP'), os.environ.get('TMP'), r'C:\Windows\Temp']
        for path in temp_paths:
            if path and os.path.exists(path):
                try:
                    for item in os.listdir(path):
                        item_path = os.path.join(path, item)
                        try:
                            if os.path.isfile(item_path):
                                os.remove(item_path)
                            elif os.path.isdir(item_path):
                                shutil.rmtree(item_path)
                        except:
                            pass
                    print(Fore.GREEN + f"[✓] {path} bereinigt")
                except Exception as e:
                    print(Fore.RED + f"[✗] Fehler bei {path}: {e}")
        self.tweaks_applied.append("Temp-Dateien bereinigt")
    
    def flush_dns(self):
        """Leert DNS-Cache"""
        print(Fore.CYAN + "\n[*] Leere DNS-Cache...")
        self.execute_command('ipconfig /flushdns', "DNS-Cache geleert")
        self.tweaks_applied.append("DNS-Cache geleert")
    
    def clean_prefetch(self):
        """Bereinigt Prefetch"""
        print(Fore.CYAN + "\n[*] Bereinige Prefetch...")
        self.execute_command('del /q/f/s C:\\Windows\\Prefetch\\*', "Prefetch bereinigt")
        self.tweaks_applied.append("Prefetch bereinigt")
    
    def empty_recycle_bin(self):
        """Leert Recycle Bin"""
        print(Fore.CYAN + "\n[*] Leere Recycle Bin...")
        self.execute_command('rd /s /q C:\\$Recycle.Bin', "Recycle Bin geleert")
        self.tweaks_applied.append("Recycle Bin geleert")
    
    def run_sfc(self):
        """Führt SFC-Scan durch"""
        print(Fore.CYAN + "\n[*] Starte SFC-Scan...")
        self.execute_command('sfc /scannow', "SFC-Scan durchgeführt")
        self.tweaks_applied.append("SFC-Scan durchgeführt")
    
    def run_dism(self):
        """Führt DISM-Scan durch"""
        print(Fore.CYAN + "\n[*] Starte DISM-Scan...")
        self.execute_command('DISM /Online /Cleanup-Image /CheckHealth', "DISM-Check")
        self.execute_command('DISM /Online /Cleanup-Image /ScanHealth', "DISM-Scan")
        self.execute_command('DISM /Online /Cleanup-Image /RestoreHealth', "DISM-Restore")
        self.tweaks_applied.append("DISM-Scan durchgeführt")
    
    def defrag(self):
        """Führt Defragmentierung durch"""
        print(Fore.CYAN + "\n[*] Starte Defragmentierung...")
        self.execute_command('defrag C: /O', "Defragmentierung durchgeführt")
        self.tweaks_applied.append("Defragmentierung durchgeführt")
    
    def clean_all(self):
        """Führt alle Bereinigungen durch"""
        print(Fore.YELLOW + "\n[!] Starte komplette Bereinigung...")
        self.clean_temp()
        self.flush_dns()
        self.clean_prefetch()
        self.empty_recycle_bin()
        print(Fore.GREEN + "\n[✓] Komplette Bereinigung abgeschlossen!")
    
    # ==================== BACKUP & RESTORE ====================
    
    def backup_menu(self):
        """Backup-Menü"""
        while True:
            self.print_header()
            print(Fore.CYAN + "    [BACKUP & RESTORE]")
            print(Fore.YELLOW + "    " + "-"*50)
            
            options = [
                ("1", "Registry-Backup erstellen"),
                ("2", "Wiederherstellungspunkt erstellen"),
                ("3", "Tweaks speichern"),
                ("4", "Tweaks laden"),
                ("5", "Backup-Verzeichnis öffnen"),
            ]
            
            for num, name in options:
                print(Fore.WHITE + f"    [{num}] {name}")
            
            print(Fore.RED + "    [0] Zurück zum Hauptmenü")
            print()
            
            choice = input(Fore.GREEN + "    Auswahl: " + Fore.WHITE)
            
            if choice == '0':
                break
            elif choice == '1':
                self.create_registry_backup()
            elif choice == '2':
                self.create_restore_point()
            elif choice == '3':
                self.save_tweaks()
            elif choice == '4':
                self.load_tweaks()
            elif choice == '5':
                self.execute_command(f'explorer "{self.backup_dir}"', "Backup-Verzeichnis geöffnet")
            
            if choice != '0':
                input(Fore.YELLOW + "\n    Drücke Enter zum Fortfahren...")
    
    def create_registry_backup(self):
        """Erstellt Registry-Backup"""
        print(Fore.CYAN + "\n[*] Erstelle Registry-Backup...")
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.execute_command(f'reg export HKLM "{self.backup_dir}\\HKLM_{timestamp}.reg"', "HKLM exportiert")
        self.execute_command(f'reg export HKCU "{self.backup_dir}\\HKCU_{timestamp}.reg"', "HKCU exportiert")
        print(Fore.GREEN + f"[✓] Backup erstellt in: {self.backup_dir}")
    
    def save_tweaks(self):
        """Speichert angewendete Tweaks"""
        print(Fore.CYAN + "\n[*] Speichere Tweaks...")
        data = {
            "timestamp": datetime.now().isoformat(),
            "tweaks": self.tweaks_applied,
            "version": self.version
        }
        with open(self.config_file, 'w') as f:
            json.dump(data, f, indent=2)
        print(Fore.GREEN + f"[✓] Tweaks gespeichert: {self.config_file}")
    
    def load_tweaks(self):
        """Lädt gespeicherte Tweaks"""
        if self.config_file.exists():
            with open(self.config_file, 'r') as f:
                data = json.load(f)
            print(Fore.CYAN + f"\n[*] Geladene Tweaks vom {data['timestamp']}:")
            for tweak in data['tweaks']:
                print(Fore.WHITE + f"    - {tweak}")
        else:
            print(Fore.RED + "[✗] Keine gespeicherten Tweaks gefunden!")
    
    # ==================== MAIN MENU ====================
    
    def main_menu(self):
        """Hauptmenü"""
        while True:
            self.print_header()
            print(Fore.CYAN + "    [HAUPTMENÜ]")
            print(Fore.YELLOW + "    " + "-"*50)
            
            menu_items = [
                ("1", "System-Tweaks", Fore.WHITE),
                ("2", "Gaming-Tweaks", Fore.WHITE),
                ("3", "Privacy-Tweaks", Fore.WHITE),
                ("4", "Network-Tweaks", Fore.WHITE),
                ("5", "🔥 Debloat", Fore.RED),
                ("6", "Wartung & Reinigung", Fore.WHITE),
                ("7", "Backup & Restore", Fore.WHITE),
                ("8", "🚀 ALLE TWEAKS", Fore.GREEN),
                ("9", "Status anzeigen", Fore.YELLOW),
            ]
            
            for num, name, color in menu_items:
                print(color + f"    [{num}] {name}")
            
            print(Fore.RED + "    [0] Beenden")
            print()
            print(Fore.CYAN + f"    Angewendete Tweaks: {len(self.tweaks_applied)}")
            print()
            
            choice = input(Fore.GREEN + "    Auswahl: " + Fore.WHITE)
            
            if choice == '1':
                self.system_tweaks_menu()
            elif choice == '2':
                self.gaming_tweaks_menu()
            elif choice == '3':
                self.privacy_tweaks_menu()
            elif choice == '4':
                self.network_tweaks_menu()
            elif choice == '5':
                self.debloat_menu()
            elif choice == '6':
                self.maintenance_menu()
            elif choice == '7':
                self.backup_menu()
            elif choice == '8':
                self.apply_all_tweaks()
                input(Fore.YELLOW + "\n    Drücke Enter zum Fortfahren...")
            elif choice == '9':
                self.show_status()
                input(Fore.YELLOW + "\n    Drücke Enter zum Fortfahren...")
            elif choice == '0':
                self.exit_program()
                break
    
    def apply_all_tweaks(self):
        """Wendet alle Tweaks an"""
        print(Fore.YELLOW + "\n" + "="*60)
        print(Fore.YELLOW + "    🚀 WENDE ALLE TWEAKS AN!")
        print(Fore.YELLOW + "="*60)
        
        self.create_restore_point("Vor_FZ_Tweaks_Komplett")
        
        print(Fore.CYAN + "\n[1/5] System-Tweaks...")
        self.apply_all_system_tweaks()
        
        print(Fore.CYAN + "\n[2/5] Gaming-Tweaks...")
        self.apply_all_gaming_tweaks()
        
        print(Fore.CYAN + "\n[3/5] Privacy-Tweaks...")
        self.apply_all_privacy_tweaks()
        
        print(Fore.CYAN + "\n[4/5] Network-Tweaks...")
        self.apply_all_network_tweaks()
        
        print(Fore.CYAN + "\n[5/5] Bereinigung...")
        self.clean_all()
        
        print(Fore.GREEN + "\n" + "="*60)
        print(Fore.GREEN + f"    ✓ ALLE {len(self.tweaks_applied)} TWEAKS ANGEWENDET!")
        print(Fore.GREEN + "="*60)
        print(Fore.YELLOW + "\n    [!] Ein Neustart wird empfohlen!")
        self.save_tweaks()
    
    def show_status(self):
        """Zeigt Status der angewendeten Tweaks"""
        self.print_header()
        print(Fore.CYAN + "    [ANGEWENDETE TWEAKS]")
        print(Fore.YELLOW + "    " + "-"*50)
        if self.tweaks_applied:
            for i, tweak in enumerate(self.tweaks_applied, 1):
                print(Fore.GREEN + f"    [{i}] {tweak}")
        else:
            print(Fore.YELLOW + "    Noch keine Tweaks angewendet.")
    
    def exit_program(self):
        """Beendet das Programm"""
        print(Fore.CYAN + "\n[*] Speichere Konfiguration...")
        if self.tweaks_applied:
            self.save_tweaks()
        print(Fore.GREEN + "\n" + "="*60)
        print(Fore.GREEN + "    Danke für die Nutzung von FZ TWEAKS!")
        print(Fore.GREEN + "    Bleib optimiert! 🚀")
        print(Fore.GREEN + "="*60 + "\n")
        time.sleep(1)


def main():
    """Hauptfunktion"""
    app = FZTweaks()
    
    # Admin-Prüfung
    if not app.is_admin():
        print(Fore.RED + "\n" + "="*60)
        print(Fore.RED + "    ⚠️  ADMINISTRATOR-RECHTE ERFORDERLICH!")
        print(Fore.RED + "="*60)
        print(Fore.YELLOW + "\n    Das Programm muss als Administrator gestartet werden.")
        print(Fore.YELLOW + "    Starte neu mit Admin-Rechten...")
        
        try:
            ctypes.windll.shell32.ShellExecuteW(
                None, "runas", sys.executable, " ".join(sys.argv), None, 1
            )
        except Exception as e:
            print(Fore.RED + f"\n[✗] Fehler: {e}")
            print(Fore.YELLOW + "\n    Bitte manuell als Administrator starten:")
            print(Fore.WHITE + "    Rechtsklick → 'Als Administrator ausführen'")
        
        sys.exit(1)
    
    # Hauptprogramm starten
    try:
        app.main_menu()
    except KeyboardInterrupt:
        print(Fore.YELLOW + "\n\n[!] Programm durch Benutzer unterbrochen.")
        sys.exit(0)
    except Exception as e:
        print(Fore.RED + f"\n\n[✗] Unerwarteter Fehler: {e}")
        app.log(f"Unexpected error: {e}", "CRITICAL")
        input(Fore.YELLOW + "\n    Drücke Enter zum Beenden...")
        sys.exit(1)


if __name__ == "__main__":
    main()